CREATE FUNCTION trigger_s_before_del () RETURNS trigger
	LANGUAGE plpgsql
AS $$
BEGIN
if (select count(*) from paper_post a where trim(a.author_id)=trim(OLD.author_id))>0
then delete from paper_post where trim(paper_post.author_id)=trim(OLD.author_id);
end if;
return OLD;
END;
$$
